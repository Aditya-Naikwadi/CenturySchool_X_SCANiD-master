﻿using LibrarySyncingService.Properties;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrarySyncingService
{
    public static class Connection
    {

        public static string lib_sqlserver = Settings.Default.lib_sqlserver;
        public static string lib_sqldb = Settings.Default.lib_sqldb;
        public static string lib_sqluser = Settings.Default.lib_sqluser;
        public static string lib_sqlpassword = Settings.Default.lib_sqlpassword;


        public static string att_sqlserver = Settings.Default.att_sqlserver;
        public static string att_sqldb = Settings.Default.att_sqldb;
        public static string att_sqluser = Settings.Default.att_sqluser;
        public static string att_sqlpassword = Settings.Default.att_sqlpassword;


        public static string payroll_sqlserver = Settings.Default.payroll_sqlserver;
        public static string payroll_sqldb = Settings.Default.payroll_sqldb;
        public static string payroll_sqluser = Settings.Default.payroll_sqluser;
        public static string payroll_sqlpassword = Settings.Default.payroll_sqlpassword;


        public static string onlinelib_sqlserver = Settings.Default.onlinelib_sqlserver;
        public static string onlinelib_sqldb = Settings.Default.onlinelib_sqldb;
        public static string onlinelib_sqluser = Settings.Default.onlinelib_sqluser;
        public static string onlinelib_sqlpassword = Settings.Default.onlinelib_sqlpassword;


        public static string puratech_sqlserver = Settings.Default.puratech_sqlserver;
        public static string puratech_sqldb = Settings.Default.puratech_sqldb;
        public static string puratech_sqluser = Settings.Default.puratech_sqluser;
        public static string puratech_sqlpassword = Settings.Default.puratech_sqlpassword;

        public static SqlConnection GetLibSqlConnection()
        {
            string sqlconnectionstring = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;MultipleActiveResultSets=true;User ID={2};Password={3}", lib_sqlserver, lib_sqldb, lib_sqluser, lib_sqlpassword);
            SqlConnection con = new SqlConnection(sqlconnectionstring);
            return con;
        }


        public static SqlConnection GetAttendanceSqlConnection()
        {
            string sqlconnectionstring = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;MultipleActiveResultSets=true;User ID={2};Password={3}", att_sqlserver, att_sqldb, att_sqluser, att_sqlpassword);
            SqlConnection con = new SqlConnection(sqlconnectionstring);
            return con;
        }


        public static SqlConnection GetPayrollSqlConnection()
        {
            string sqlconnectionstring = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;MultipleActiveResultSets=true;User ID={2};Password={3}", payroll_sqlserver, payroll_sqldb, payroll_sqluser, payroll_sqlpassword);
            SqlConnection con = new SqlConnection(sqlconnectionstring);
            return con;
        }


        public static SqlConnection GetPuratechSqlConnection()
        {
            string sqlconnectionstring = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;MultipleActiveResultSets=true;User ID={2};Password={3}", puratech_sqlserver, puratech_sqldb, puratech_sqluser, puratech_sqlpassword);
            SqlConnection con = new SqlConnection(sqlconnectionstring);
            return con;
        }

        public static SqlConnection GetOnlineLibSqlConnection()
        {
            string sqlconnectionstring = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;MultipleActiveResultSets=true;User ID={2};Password={3}", onlinelib_sqlserver, onlinelib_sqldb, onlinelib_sqluser, onlinelib_sqlpassword);
            SqlConnection con = new SqlConnection(sqlconnectionstring);
            return con;
        }


        //public static SqlConnection GetOnlineSqlConnection()
        //{
        //    string sqlconnectionstring = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;MultipleActiveResultSets=true;User ID={2};Password={3}", online_sql_server, online_sql_database, online_sql_user, online_sql_password);
        //    SqlConnection con = new SqlConnection(sqlconnectionstring);
        //    return con;
        //}

    }
}
