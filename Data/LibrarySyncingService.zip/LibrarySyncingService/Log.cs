﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrarySyncingService
{
    public class Log
    {
        private static readonly Log _instance = new Log();
        protected ILog errorlogger;
        protected ILog eventlogger;


        private Log()
        {
            errorlogger = LogManager.GetLogger("DataLogs");
            eventlogger = LogManager.GetLogger("eventlogger");
        }

        public static void Info(string message)
        {
            _instance.errorlogger.Info(message);
            Console.WriteLine(message);
        }


        public static void Error(string message, System.Exception exception)
        {
            _instance.errorlogger.Error(message, exception);
            Console.WriteLine(exception.Message);
        }

        public static void ErrorMessage(string message, string exceptionmsg)
        {
            _instance.errorlogger.Error(message + " : " + exceptionmsg);
        }


        public static void event_Info(string message)
        {
            _instance.eventlogger.Info(message);
            Console.WriteLine(message);
        }



    }
}
