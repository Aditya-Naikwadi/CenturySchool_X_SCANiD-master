﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrarySyncingService
{
    class SQL
    {
        private System.Data.SqlClient.SqlConnection SqlConnection { get; set; }

        private string _connectionString;
        /// <summary>
        /// Gets or Set sql connection string
        /// </summary>
        public string ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(this._connectionString) == true)
                    return string.Empty;
                return _connectionString;
            }
            set { _connectionString = value; }
        }

        private System.Data.SqlClient.SqlBulkCopy SqlBroker { get; set; }
        /// <summary>
        /// Initiates connection string
        /// </summary>
        /// <param name="connectionstring">sting type, Gets or Set sql connection string</param>
        public SQL(string TargetConnectionString)
        {
            try
            {
                if (string.IsNullOrEmpty(TargetConnectionString) == true)
                    throw new Exception("Empty connection string");
                this.ConnectionString = TargetConnectionString;
                this.SqlConnection = new System.Data.SqlClient.SqlConnection();
                this.SqlConnection.ConnectionString = this.ConnectionString;
                this.SqlConnection.Open();
            }
            catch
            {
                throw;
            }

        }
        public SQL(System.Data.SqlClient.SqlConnection TargetConnection)
        {
            if (TargetConnection.State != System.Data.ConnectionState.Open)
                this.SqlConnection.Open();
        }

        private System.Data.SqlClient.SqlConnection OpenConnection()
        {
            try
            {
                if (string.IsNullOrEmpty(this.ConnectionString) == true)
                    throw new Exception("Empty connection string");
                this.SqlConnection = new System.Data.SqlClient.SqlConnection();
                this.SqlConnection.ConnectionString = this.ConnectionString;
                this.SqlConnection.Open();
                return this.SqlConnection;
            }
            catch
            {
                throw;
            }
        }
        public bool Backup(System.Data.DataTable SourceTable, string TargetTable)
        {
            try
            {
                if (this.SqlBroker == null)
                    this.NewBroaker();
                this.SqlBroker.DestinationTableName = TargetTable;
                //start extra code
                this.SqlBroker.BatchSize = 5000;
                this.SqlBroker.BulkCopyTimeout = 2000;
                //end extra
                this.SqlBroker.WriteToServer(SourceTable);
                //this.SqlBroker.WriteToServer(SourceTable);
                return true;
            }
            catch
            {
                throw;
            }
        }
        public bool Backup(System.Data.DataTable SourceTable, string TargetTable, string[] SourceColumns, string[] DestinationColumns)
        {
            try
            {
                if (SourceColumns.Count() != DestinationColumns.Count())
                    throw new Exception("The number of source column and destination columns should be same");
                this.NewBroaker();

                for (int ind = 0; ind < SourceColumns.Length; ind++)
                {
                    System.Data.SqlClient.SqlBulkCopyColumnMapping mapping = new System.Data.SqlClient.SqlBulkCopyColumnMapping();
                    mapping.SourceColumn = SourceColumns[ind];
                    mapping.DestinationColumn = DestinationColumns[ind];
                    this.SqlBroker.ColumnMappings.Add(mapping);
                }
                return this.Backup(SourceTable, TargetTable);
            }
            catch
            {
                throw;
            }
        }
        private void NewBroaker()
        {
            try
            {
                if (this.SqlConnection != null || this.SqlConnection.State != System.Data.ConnectionState.Open)
                    this.OpenConnection();
                this.SqlBroker = new System.Data.SqlClient.SqlBulkCopy(this.SqlConnection);
            }
            catch
            {
                throw;
            }
        }
    }
}
