﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LibrarySyncingService
{
    public partial class LibrarySyncingService : ServiceBase
    {
        object locked = new object();
        object locked2 = new object();
        System.Timers.Timer timer = new System.Timers.Timer();
        System.Timers.Timer syncreservation = new System.Timers.Timer();
        public LibrarySyncingService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            StartOperation();
        }

        protected override void OnStop()
        {
            Log.Info("LibrarySyncingService Service Stopped");
        }


        public void StartOperation()
        {
            try
            {
               
                Log.Info("LibrarySyncingService Service Started");
                timer.Elapsed += Timer_Elapsed;
                //timer interval is every 3 hours
                //timer.Interval = 3 * 60 * 60 * 1000; //number in milisecinds  1 min =60000 miliseconds  10 min

                timer.Interval = 50000; // timer interval is every 50 sec

                timer.Enabled = true;
                Log.Info("LibrarySyncingService Timer Started");

                syncreservation.Elapsed += Syncreservation_Elapsed;
                syncreservation.Interval = 60000*1;//1 min sceduel
                syncreservation.Enabled = true;
                Log.Info("Syncreservation Timer Started");




            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.StartOperation", ex);
            }
        }

       

        private void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (Monitor.TryEnter(locked))
            {
                try
                {
                    string ctime = DateTime.Now.ToString("HH:mm");

                   if(ctime.Equals("15:25") || ctime.Equals("13:00") || ctime.Equals("22:00") || ctime.Equals("19:20"))
                    {
                        updateBookMasterToOnlineLibrary();

                        updateStudentMaster();


                        updateStaffMaster();

                        updatePeriodicals();

                    }

                    Monitor.Exit(locked);

                }
                catch (Exception ex)
                {
                    Log.Error("LibrarySyncingService.email_timer_Elapsed", ex);
                    Monitor.Exit(locked);
                }


            }
            else
            {
                Log.Info("Email Timer Elapsed,Work Going on OnElapsedTime()");
            }
        }


        private void Syncreservation_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (Monitor.TryEnter(locked2))
            {
                try
                {
                    TimeSpan start = new TimeSpan(6, 0, 0); //6 o'clock
                    TimeSpan end = new TimeSpan(19, 0, 0); //7 o'clock evening
                    TimeSpan now = DateTime.Now.TimeOfDay;

                    if ((now >=start) && (now <= end))
                    {
                        //match found

                        updateBookReservationMaster();

                        updateBookIssues();

                        updatesuggesstionBooks();


                        checkForBookReservationExpiration();


                    }

                   

                    

                    Monitor.Exit(locked2);

                }
                catch (Exception ex)
                {
                    Log.Error("LibrarySyncingService.Syncreservation_Elapsed", ex);
                    Monitor.Exit(locked2);
                }
            }
            else
            {
                Log.Info("Syncreservation_Elapsed Elapsed,Work Going on OnElapsedTime()");
            }
        }


        public void updateStudentMaster()
        {
            Log.Info("updateStudentMaster started");
            SqlConnection con = null;
            DataTable studentTable = new DataTable();
            try
            {
                string query = "";
                SqlCommand cmd = null;
                SqlDataAdapter adap = null;
                using (con = Connection.GetAttendanceSqlConnection())
                {
                    con.Open();
                    query = "select Fname,Mname,Lname,std,div,rollno,grno,gender,dob,address,mobile,SHIFTNAME,doa,PHOTOPATH,CARDID,sms,fullname,admissiontype,Nationality,DateofLeaving,schoolsection,academicyear,uniformid "+
                            "from studentmaster;";
                    cmd = new SqlCommand(query, con);
                    adap = new SqlDataAdapter(cmd);
                    adap.Fill(studentTable);

                    con.Close();
                }


                using (con = Connection.GetLibSqlConnection())
                {
                    con.Open();

                    foreach(DataRow ro in studentTable.Rows)
                    {
                        query = "select Count(*) from studentmaster where std='"+ro["std"].ToString() +"' and grno='"+ro["grno"].ToString() +"' and academicyear='"+ ro["academicyear"].ToString() + "';";
                        cmd = new SqlCommand(query, con);
                        var rcnt = cmd.ExecuteScalar();
                        if (!String.IsNullOrEmpty(rcnt.ToString()))
                        {
                            if (Convert.ToInt32(rcnt) == 0)
                            {
                                //insert new record
                                query = "insert into studentmaster(Fname,Mname,Lname,std,div,rollno,grno,gender,dob,address,mobile,SHIFTNAME,doa,PHOTOPATH,CARDID,sms,fullname,admissiontype,Nationality,DateofLeaving,schoolsection,academicyear,uniformid) "+
                                        "values(@Fname,@Mname,@Lname,@std,@div,@rollno,@grno,@gender,@dob,@address,@mobile,@SHIFTNAME,@doa,@PHOTOPATH,@CARDID,@sms,@fullname,@admissiontype,@Nationality,@DateofLeaving,@schoolsection,@academicyear,@uniformid);";
                                
                            }
                            else
                            {
                                //update existing record
                                query = "update studentmaster set Fname=@Fname,Mname=@Mname,Lname=@Lname,div=@div,rollno=@rollno,gender=@gender,dob=@dob,[address]=@address,mobile=@mobile,SHIFTNAME=@SHIFTNAME,doa=@doa,PHOTOPATH=@PHOTOPATH,CARDID=@CARDID,sms=@sms,fullname=@fullname,admissiontype=@admissiontype,Nationality=@Nationality,DateofLeaving=@DateofLeaving,schoolsection=@schoolsection,uniformid=@uniformid "+
                                        "where std=@std and grno=@grno and academicyear=@academicyear;";
                            }

                            cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@Fname",ro["Fname"].ToString());
                            cmd.Parameters.AddWithValue("@Mname", ro["Mname"].ToString());
                            cmd.Parameters.AddWithValue("@Lname", ro["Lname"].ToString());
                            cmd.Parameters.AddWithValue("@std", ro["std"].ToString());
                            cmd.Parameters.AddWithValue("@div", ro["div"].ToString());
                            cmd.Parameters.AddWithValue("@rollno", ro["rollno"].ToString());
                            cmd.Parameters.AddWithValue("@grno", ro["grno"].ToString());
                            cmd.Parameters.AddWithValue("@gender", ro["gender"].ToString());
                            cmd.Parameters.AddWithValue("@dob", ro["dob"].ToString());
                            cmd.Parameters.AddWithValue("@address", ro["address"].ToString());
                            cmd.Parameters.AddWithValue("@mobile", ro["mobile"].ToString());
                            cmd.Parameters.AddWithValue("@SHIFTNAME", ro["SHIFTNAME"].ToString());
                            cmd.Parameters.AddWithValue("@doa", ro["doa"].ToString());
                            cmd.Parameters.AddWithValue("@PHOTOPATH", ro["PHOTOPATH"].ToString());
                            cmd.Parameters.AddWithValue("@CARDID", ro["CARDID"].ToString());
                            cmd.Parameters.AddWithValue("@sms", ro["sms"].ToString());
                            cmd.Parameters.AddWithValue("@fullname", ro["fullname"].ToString());
                            cmd.Parameters.AddWithValue("@admissiontype", ro["admissiontype"].ToString());
                            cmd.Parameters.AddWithValue("@Nationality", ro["Nationality"].ToString());
                            cmd.Parameters.AddWithValue("@DateofLeaving", ro["DateofLeaving"].ToString());
                            cmd.Parameters.AddWithValue("@schoolsection", ro["schoolsection"].ToString());
                            cmd.Parameters.AddWithValue("@academicyear", ro["academicyear"].ToString());
                            cmd.Parameters.AddWithValue("@uniformid", ro["uniformid"].ToString());
                            cmd.ExecuteNonQuery();
                        }


                    }
                    con.Close();
                }
                Log.Info("updateStudentMaster completed successfully");
            }
            catch(Exception ex)
            {
                Log.Error("LibrarySyncingService.updateStudentMaster", ex);
            }
            finally
            {
                if (con != null) { con.Close(); }
                studentTable.Dispose();
            }
        }





        public void updateStaffMaster()
        {
            Log.Info("updateStaffMaster started");
            SqlConnection con = null;
            DataTable staffTable = new DataTable();
            try
            {
                string query = "";
                SqlCommand cmd = null;
                SqlDataAdapter adap = null;
                using (con = Connection.GetPayrollSqlConnection())
                {
                    con.Open();
                    query = "select employee_code,initials,first_name,middle_name,surname,date_of_birth,date_of_joining,date_of_leaving,designation,shift_code,gender,emailid,[address],emp_mobile " +
                            "from staffmaster;";
                    cmd = new SqlCommand(query, con);
                    adap = new SqlDataAdapter(cmd);
                    adap.Fill(staffTable);

                    con.Close();
                }

              
                //update staffmaster in local library connection
                using (con = Connection.GetLibSqlConnection())
                {
                    con.Open();

                    foreach (DataRow ro in staffTable.Rows)
                    {
                        query = "select Count(*) from staffmaster where EMPCODE='"+ro["employee_code"].ToString() +"';";
                        cmd = new SqlCommand(query, con);
                        var rcnt = cmd.ExecuteScalar();
                        if (!String.IsNullOrEmpty(rcnt.ToString()))
                        {
                            if (Convert.ToInt32(rcnt) == 0)
                            {
                                //insert new record
                                query = "insert into staffmaster(Fname,DESIGNATION,EMPCODE,std,div,ISCLASSTEACHER,GENDER,DOB,mobile,email,shiftname,doa,cardid,RETIREMENT,INITIALS) " +
                                        "values(@Fname,@DESIGNATION,@EMPCODE,@std,@div,@ISCLASSTEACHER,@GENDER,@DOB,@mobile,@email,@shiftname,@doa,@cardid,@RETIREMENT,@INITIALS);";

                            }
                            else
                            {
                                //update existing record
                                query = "update staffmaster set Fname=@Fname,DESIGNATION=@DESIGNATION,std=@std,div=@div,ISCLASSTEACHER=@ISCLASSTEACHER,GENDER=@GENDER,DOB=@DOB,mobile=@mobile,email=@email,shiftname=@shiftname,doa=@doa,cardid=@cardid,RETIREMENT=@RETIREMENT,INITIALS=@INITIALS " +
                                        "where EMPCODE=@EMPCODE;";
                            }

                            cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@Fname", ro["first_name"].ToString()+" "+ ro["surname"].ToString());
                            cmd.Parameters.AddWithValue("@DESIGNATION", ro["designation"].ToString());
                            cmd.Parameters.AddWithValue("@EMPCODE", ro["employee_code"].ToString());
                            cmd.Parameters.AddWithValue("@std","-");
                            cmd.Parameters.AddWithValue("@div","-");
                            cmd.Parameters.AddWithValue("@ISCLASSTEACHER","0");
                            cmd.Parameters.AddWithValue("@GENDER", ro["gender"].ToString());
                            cmd.Parameters.AddWithValue("@DOB", ro["date_of_birth"].ToString());
                            cmd.Parameters.AddWithValue("@mobile", ro["emp_mobile"].ToString());
                            cmd.Parameters.AddWithValue("@email", ro["emailid"].ToString());
                            cmd.Parameters.AddWithValue("@shiftname", ro["shift_code"].ToString());
                            cmd.Parameters.AddWithValue("@doa", ro["date_of_joining"].ToString());
                            cmd.Parameters.AddWithValue("@cardid","0000000000");
                            cmd.Parameters.AddWithValue("@RETIREMENT", ro["date_of_leaving"].ToString());
                            cmd.Parameters.AddWithValue("@INITIALS", ro["initials"].ToString());
                           
                            cmd.ExecuteNonQuery();
                        }


                    }
                    con.Close();
                }
                Log.Info("updateStaffMaster Local Library completed successfully");

                //update staffmaster in online library connection
                using (con = Connection.GetOnlineLibSqlConnection())
                {
                    con.Open();

                    foreach (DataRow ro in staffTable.Rows)
                    {
                        query = "select Count(*) from staffmaster where EMPCODE='" + ro["employee_code"].ToString() + "';";
                        cmd = new SqlCommand(query, con);
                        var rcnt = cmd.ExecuteScalar();
                        if (!String.IsNullOrEmpty(rcnt.ToString()))
                        {
                            if (Convert.ToInt32(rcnt) == 0)
                            {
                                //insert new record
                                query = "insert into staffmaster(Fname,DESIGNATION,EMPCODE,std,div,ISCLASSTEACHER,GENDER,DOB,mobile,email,shiftname,doa,cardid,RETIREMENT,INITIALS) " +
                                        "values(@Fname,@DESIGNATION,@EMPCODE,@std,@div,@ISCLASSTEACHER,@GENDER,@DOB,@mobile,@email,@shiftname,@doa,@cardid,@RETIREMENT,@INITIALS);";

                            }
                            else
                            {
                                //update existing record
                                query = "update staffmaster set Fname=@Fname,DESIGNATION=@DESIGNATION,std=@std,div=@div,ISCLASSTEACHER=@ISCLASSTEACHER,GENDER=@GENDER,DOB=@DOB,mobile=@mobile,email=@email,shiftname=@shiftname,doa=@doa,cardid=@cardid,RETIREMENT=@RETIREMENT,INITIALS=@INITIALS " +
                                        "where EMPCODE=@EMPCODE;";
                            }

                            cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@Fname", ro["first_name"].ToString() + " " + ro["surname"].ToString());
                            cmd.Parameters.AddWithValue("@DESIGNATION", ro["designation"].ToString());
                            cmd.Parameters.AddWithValue("@EMPCODE", ro["employee_code"].ToString());
                            cmd.Parameters.AddWithValue("@std", "-");
                            cmd.Parameters.AddWithValue("@div", "-");
                            cmd.Parameters.AddWithValue("@ISCLASSTEACHER", "0");
                            cmd.Parameters.AddWithValue("@GENDER", ro["gender"].ToString());
                            cmd.Parameters.AddWithValue("@DOB", ro["date_of_birth"].ToString());
                            cmd.Parameters.AddWithValue("@mobile", ro["emp_mobile"].ToString());
                            cmd.Parameters.AddWithValue("@email", ro["emailid"].ToString());
                            cmd.Parameters.AddWithValue("@shiftname", ro["shift_code"].ToString());
                            cmd.Parameters.AddWithValue("@doa", ro["date_of_joining"].ToString());
                            cmd.Parameters.AddWithValue("@cardid", "0000000000");
                            cmd.Parameters.AddWithValue("@RETIREMENT", ro["date_of_leaving"].ToString());
                            cmd.Parameters.AddWithValue("@INITIALS", ro["initials"].ToString());

                            cmd.ExecuteNonQuery();
                        }


                    }
                    con.Close();
                }
                Log.Info("updateStaffMaster Online Library completed successfully");



            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.updateStaffMaster", ex);
            }
            finally
            {
                if (con != null) { con.Close(); }
                staffTable.Dispose();
            }
        }


        public void updateBookReservationMaster()
        {
            Log.Info("updateBookReservationMaster started");

            SqlConnection con = null;
            SqlConnection onlinecon = null;
            DataTable Online_BookReservationMaster = new DataTable();
            DataTable Local_BookReservationMaster = new DataTable();
            try
            {
                //pull lastest bookreservation from Online bookreservation master
                using (con = Connection.GetOnlineLibSqlConnection())
                {
                    con.Open();

                    string query = "select BookReserve_Id,BookId,AccessionNo,BookTagId,BookName,ReservationDate,ReservationStatus,issuedate,issuestatus,reservedbycode,reservedbyname,isstudent,'1' as issynced,reserve_status,updateddatetime,std,div " +
                                   "from BookReservationMaster where issynced = '-' and reserve_status='active';";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adap = new SqlDataAdapter(cmd);
                    adap.Fill(Online_BookReservationMaster);

                

                        Boolean isexecuted = false;
                
                        //push the bookreservation from online to local library bookreservation master
                        SQL sql2 = new SQL("Data Source=" + Connection.lib_sqlserver + ";Initial Catalog=" + Connection.lib_sqldb + ";User ID=" +Connection.lib_sqluser+ ";Password=" +Connection.lib_sqlpassword+ "");
                       isexecuted=sql2.Backup(Online_BookReservationMaster, "BookReservationMaster");

                    //if isexecuted is true then update the issynced flag=1 in the online BookReservationMaster
                    if (isexecuted)
                    {
                            foreach(DataRow ro in Online_BookReservationMaster.Rows)
                            {
                                query = "update BookReservationMaster set issynced='1' where BookReserve_Id='"+ ro["BookReserve_Id"].ToString() + "';";
                                cmd = new SqlCommand(query, con);
                                cmd.ExecuteNonQuery();

                            }

                    }
                    con.Close();
               }

                //update any bookreservation from local bookreservation master to online bookreservation master for isssues or expiration status
                using(con=Connection.GetLibSqlConnection())
                {
                    con.Open();
                    string query1 = "select BookReserve_Id,BookId,AccessionNo,BookTagId,BookName,ReservationDate,ReservationStatus,Convert(nvarchar(10),Cast(issuedate as Date),111) as issuedate,issuestatus,reservedbycode,reservedbyname,isstudent,'1' as issynced,reserve_status,updateddatetime,std,div " +
                             "from BookReservationMaster where issynced = '-' and reserve_status = 'active';";
                    SqlCommand cmd1 = new SqlCommand(query1, con);
                    SqlDataAdapter adap1 = new SqlDataAdapter(cmd1);
                    adap1.Fill(Local_BookReservationMaster);


                    using (onlinecon = Connection.GetOnlineLibSqlConnection())
                    {
                        onlinecon.Open();
                        foreach (DataRow ro in Local_BookReservationMaster.Rows)
                        {

                            //update booissued , book expired in online bookreservation master
                            query1 = "update BookReservationMaster set ReservationStatus='" + ro["ReservationStatus"].ToString() + "',IssueDate='" + ro["issuedate"].ToString() + "',IssueStatus='" + ro["issuestatus"].ToString() + "',updateddatetime='" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "' " +
                                     "where BookReserve_Id='" + ro["BookReserve_Id"].ToString() + "' and bookid='" + ro["BookId"].ToString() + "';";
                            cmd1 = new SqlCommand(query1, onlinecon);
                            cmd1.ExecuteNonQuery();


                            //update local database for already synced
                            query1 = "update BookReservationMaster set issynced='1',updateddatetime='"+DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")+"' "+
                                       "where BookReserve_Id='" + ro["BookReserve_Id"].ToString() + "' and bookid='" + ro["BookId"].ToString() + "';";
                            cmd1 = new SqlCommand(query1, con);
                            cmd1.ExecuteNonQuery();
                        }
                    }
                    


                }
               




                Log.Info("updateBookReservationMaster Local Library completed successfully");
            }
            catch(Exception ex)
            {
                Log.Error("LibrarySyncingService.updateBookReservationMaster", ex);
            }
            finally
            {
                Online_BookReservationMaster.Dispose();
                if (con != null) { con.Close(); }
            }
        }

        public void updateBookIssues()
        {
            Log.Info("updateBookIssues started");

            SqlConnection con = null;
            SqlConnection onlinecon = null;
            DataTable Local_BookIssues = new DataTable();
            try
            {
                //pull lastest BookIssues from Local BookIssues master
                using (con = Connection.GetLibSqlConnection())
                {
                    con.Open();

                    string query = "select [issuedate],[issuetime],[bookid],[bookname],[book_tagid],[grno],[std],[div],[rollno],[studentname],[bookloc],[status],[returndate],[returntime],[isStudent],[isOnline],[returnFrom],'1' as issynced "+
                                   "From [BookIssues] where issynced is null;";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adap = new SqlDataAdapter(cmd);
                    adap.Fill(Local_BookIssues);

                    //Delete updated books from online issue book table
                    using (onlinecon = Connection.GetOnlineLibSqlConnection())
                    {
                        onlinecon.Open();
                        foreach (DataRow ro in Local_BookIssues.Rows)
                        {
                            query = "Delete from BookIssues where issuedate='" + ro["issuedate"].ToString() + "' and issuetime='" + ro["issuetime"].ToString() + "' and bookid='" + ro["bookid"].ToString() + "' and grno='" + ro["grno"].ToString() + "';";
                            cmd = new SqlCommand(query, onlinecon);
                            cmd.ExecuteNonQuery();
                        
                        }
                        onlinecon.Close();
                    }


                        Boolean isexecuted = false;

                    //push the BookIssues from local to online library BookIssues master
                    SQL sql2 = new SQL("Data Source=" + Connection.onlinelib_sqlserver + ";Initial Catalog=" + Connection.onlinelib_sqldb + ";User ID=" + Connection.onlinelib_sqluser + ";Password=" + Connection.onlinelib_sqlpassword + "");
                    isexecuted = sql2.Backup(Local_BookIssues, "BookIssues");

                    //if isexecuted is true then update the issynced flag=1 in the local BookIssues
                    if (isexecuted)
                    {
                        foreach (DataRow ro in Local_BookIssues.Rows)
                        {
                            //update bookissues table
                            query = "update BookIssues set issynced='1' "+
                                "where issuedate='"+ ro["issuedate"].ToString() + "' and issuetime='"+ ro["issuetime"].ToString() + "' and bookid='"+ ro["bookid"].ToString() + "' and grno='"+ ro["grno"].ToString() + "';";
                            cmd = new SqlCommand(query, con);
                            cmd.ExecuteNonQuery();


                            //revert any blockexpiration status if book is returned in local bookreservation
                            if (ro["status"].ToString().Equals(EnumClass.returned))
                            {
                                query = "update BookReservationMaster set reservationDate='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "',blockexpiration='0' where bookid='" + ro["bookid"].ToString() + "' and blockexpiration='1';";
                                cmd = new SqlCommand(query, con);
                                cmd.ExecuteNonQuery();
                            }


                            using (onlinecon = Connection.GetOnlineLibSqlConnection())
                            {
                                onlinecon.Open();
                                //update existing online bookmaster table also
                                if (ro["status"].ToString().Equals(EnumClass.issued))
                                {
                                    query = "update BookMaster set bookstatus='" + EnumClass.issued + "',isreserved=null where bookid='" + ro["bookid"].ToString() + "';";
                                }
                                else
                                {
                                    query = "update BookMaster set bookstatus='" + EnumClass.available + "',isreserved=null where bookid='" + ro["bookid"].ToString() + "';";
                                }
                                cmd = new SqlCommand(query, onlinecon);
                                cmd.ExecuteNonQuery();
                                


                                //revert any blockexpiration status if book is returned in online bookreservation
                                if (ro["status"].ToString().Equals(EnumClass.returned))
                                {
                                    query = "update BookReservationMaster set reservationDate='"+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+"',blockexpiration='0' where bookid='" + ro["bookid"].ToString() + "' and blockexpiration='1';";
                                    cmd = new SqlCommand(query, onlinecon);
                                    cmd.ExecuteNonQuery();
                                }

                                onlinecon.Close();
                            }
                           

                        }

                    }
                }

                Log.Info("updateBookIssues Local Library completed successfully");
            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.updateBookIssues", ex);
            }
            finally
            {
                Local_BookIssues.Dispose();
                if (con != null) { con.Close(); }

                if (onlinecon != null) { onlinecon.Close(); }
            }
        }


        public void updatesuggesstionBooks()
        {
            Log.Info("updatesuggesstionBooks started");

            SqlConnection con = null;
            DataTable Online_BookSuggesst = new DataTable();
            try
            {
                //pull lastest BookSuggesst from Online BookSuggestions master
                using (con = Connection.GetOnlineLibSqlConnection())
                {
                    con.Open();

                    string query = "select id,date1,bookname,authorname,isbn,suggestbyname,suggestbycode,isstudent,'1' as issync,bookjson,[status],updateddatetime "+
                                   "from BookSuggestions "+
                                   "where issync = '-' and [status] = 'active';";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adap = new SqlDataAdapter(cmd);
                    adap.Fill(Online_BookSuggesst);



                    Boolean isexecuted = false;

                    //push the BookSuggesst from online to local library BookSuggestions master
                    SQL sql2 = new SQL("Data Source=" + Connection.lib_sqlserver + ";Initial Catalog=" + Connection.lib_sqldb + ";User ID=" + Connection.lib_sqluser + ";Password=" + Connection.lib_sqlpassword + "");
                    isexecuted = sql2.Backup(Online_BookSuggesst, "BookSuggestions");

                    //if isexecuted is true then update the issynced flag=1 in the online BookReservationMaster
                    if (isexecuted)
                    {
                        foreach (DataRow ro in Online_BookSuggesst.Rows)
                        {
                            query = "update BookSuggestions set issync='1' where id='" + ro["id"].ToString() + "';";
                            cmd = new SqlCommand(query, con);
                            cmd.ExecuteNonQuery();

                        }

                    }
                }

                Log.Info("updatesuggesstionBooks Local Library completed successfully");
            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.updatesuggesstionBooks", ex);
            }
            finally
            {
                Online_BookSuggesst.Dispose();
                if (con != null) { con.Close(); }
            }
        }


        public void checkForBookReservationExpiration()
        {

            Log.Info("checkForBookReservationExpiration started");
           
            SqlConnection con = null;
            SqlConnection online_con = null;
            DataTable BookReservation = new DataTable();
            try
            {
                //get reservation expired records
                using (con = Connection.GetLibSqlConnection())
                {
                    con.Open();




                    //string query = "Select BookReserve_Id,bookid,AccessionNo,BookTagId,BookName,ReservationDate,ReservationStatus,reservedbycode,reservedbyname,isstudent,CASE WHEN DATEDIFF(hour, ReservationDate, getDate()) >= 24 THEN 'Expired' ELSE 'OK' END EllapsedDays,blockexpiration " +
                    //         "FROM BookReservationMaster " +
                    //         "where reservationstatus = 'reserved' and reserve_status = 'active' and blockexpiration='0';";



                    string query = "Select BookReserve_Id,bookid,AccessionNo,BookTagId,BookName,ReservationDate,ReservationStatus,reservedbycode,reservedbyname,isstudent,CASE WHEN DATEDIFF(MINUTE, ReservationDate, getDate()) >= 1440 THEN 'Expired' ELSE 'OK' END EllapsedDays,blockexpiration " +
                          "FROM BookReservationMaster " +
                          "where reservationstatus = 'reserved' and reserve_status = 'active' and blockexpiration='0';";


                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adap = new SqlDataAdapter(cmd);
                    adap.Fill(BookReservation);

                    using (online_con = Connection.GetOnlineLibSqlConnection())
                    {
                        online_con.Open();

                        string currentdate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss").Replace('-', '/');
                        foreach (DataRow ro in BookReservation.Rows)
                        {
                            if(ro["EllapsedDays"].ToString().Equals("Expired"))
                            {
                                //check wethere book is issued by some else, because then only the reservation will be active
                                query = "select Count(*) from BookIssues where bookid='"+ro["bookid"].ToString() +"' and[status] = 'issued';";
                                cmd = new SqlCommand(query, con);
                                var rcnt = cmd.ExecuteScalar();
                                int bkissuecount = 0;
                                if (!string.IsNullOrEmpty(rcnt.ToString()))
                                {
                                    bkissuecount = Convert.ToInt32(rcnt);
                                }

                                if (bkissuecount == 0)
                                {
                                    //update local bookreservationmaster table
                                    query = "update BookReservationMaster set ReservationStatus='Expired',updateddatetime='" + currentdate + "' " +
                                        "where BookReserve_Id = '" + ro["BookReserve_Id"].ToString() + "';";
                                    cmd = new SqlCommand(query, con);
                                    cmd.ExecuteNonQuery();

                                    //update online bookreservationmaster table
                                    cmd = new SqlCommand(query, online_con);
                                    cmd.ExecuteNonQuery();


                                    //update local bookmaster table
                                    query = "update BookMaster set isreserved=null where bookid='" + ro["bookid"].ToString() + "';";
                                    cmd = new SqlCommand(query, con);
                                    cmd.ExecuteNonQuery();

                                    //update online bookmaster table
                                    cmd = new SqlCommand(query, online_con);
                                    cmd.ExecuteNonQuery();
                                }
                                else
                                {
                                    //block the expiration for the book

                                    //update local bookreservationmaster table
                                    query = "update BookReservationMaster set blockexpiration='1' where BookReserve_Id='"+ ro["BookReserve_Id"].ToString() + "';";
                                    cmd = new SqlCommand(query, con);
                                    cmd.ExecuteNonQuery();

                                    //update online bookreservationmaster table
                                    cmd = new SqlCommand(query, online_con);
                                    cmd.ExecuteNonQuery();

                                }
                            }
                            
                        }
                    }
                       

                    
                }

                Log.Info("checkForBookReservationExpiration completed successfully");
            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.checkForBookReservationExpiration", ex);
            }
            finally
            {
                BookReservation.Dispose();

                if (online_con != null) { online_con.Close(); }
                if (con != null) { con.Close(); }
            }
        }


        public void updateBookMasterToOnlineLibrary()
        {
            Log.Info("updateBookMasterToOnlineLibrary started");
            SqlConnection con = null;
            DataTable bookmaster = new DataTable();

            int localbookscount = 0;
            int onlinebookscount = 0;
            try
            {
                string query = "";
                SqlCommand cmd = null;
                SqlDataAdapter adap = null;

                //Local Library SqlConnection
                using (con = Connection.GetLibSqlConnection())
                {
                    //Get ALL books from local
                    con.Open();
                    query = "select [Bookid],[AccNo],[category],[accnocat],[Bookname],[Booktype],editor,edition,[Author_Name1],[Author_Name2],[language],[Quantity],[Cost],[costdiscount],yearofpub,[eresource],pages,referencebk,dateofentry,[book_photo],[Book_tagid],[room_location],[BookUpdatedDateTime],[org_book_loc],[locupdatetype],[isbn],[subjectkeyword],[manuallibrary],[manualcupbourd],[manualshelf],[bookstatus],[damagedtype],withdrawdate,supplybillno,remarks,classification,modifieddate,publisher,booksummary,libraryscan,BookReserve_Id,place_publication,isreserved "+
                            "from BookMaster;";
                    cmd = new SqlCommand(query, con);
                    adap = new SqlDataAdapter();
                    adap.SelectCommand = cmd;
                    adap.Fill(bookmaster);
                    con.Close();

                    localbookscount = bookmaster.Rows.Count;
                }

                using (con = Connection.GetOnlineLibSqlConnection())
                {
                    //delete books from online database
                    con.Open();
                    query = "Delete from BookMaster;";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    Boolean isexecuted = false;

                    //push the Local BookMaster to online Book master
                    SQL sql2 = new SQL("Data Source=" + Connection.onlinelib_sqlserver + ";Initial Catalog=" + Connection.onlinelib_sqldb + ";User ID=" + Connection.onlinelib_sqluser + ";Password=" + Connection.onlinelib_sqlpassword + "");
                    isexecuted = sql2.Backup(bookmaster, "BookMaster");

                    //if isexecuted is true then update the issynced flag=1 in the online BookReservationMaster
                    if (isexecuted)
                    {
                        query = "select Count(*) From BookMaster;";
                        cmd = new SqlCommand(query, con);
                        var rcnt = cmd.ExecuteScalar();
                        if(!string.IsNullOrEmpty(rcnt.ToString()))
                        {
                            onlinebookscount = Convert.ToInt32(rcnt);
                        }

                        if (onlinebookscount == localbookscount)
                        {
                            Log.Info("updateBookMasterToOnlineLibrary completed successfully");
                        }
                        else
                        {
                            Thread.Sleep(60000);
                            //retry second time after 1min

                            query = "Delete from BookMaster;";
                            cmd = new SqlCommand(query, con);
                            cmd.ExecuteNonQuery();

                            isexecuted = false;

                            //push the Local BookMaster to online Book master
                             sql2 = new SQL("Data Source=" + Connection.onlinelib_sqlserver + ";Initial Catalog=" + Connection.onlinelib_sqldb + ";User ID=" + Connection.onlinelib_sqluser + ";Password=" + Connection.onlinelib_sqlpassword + "");
                            isexecuted = sql2.Backup(bookmaster, "BookMaster");

                            if (isexecuted)
                            {
                                onlinebookscount = 0;
                                query = "select Count(*) From BookMaster;";
                                cmd = new SqlCommand(query, con);
                                 rcnt = cmd.ExecuteScalar();
                                if (!string.IsNullOrEmpty(rcnt.ToString()))
                                {
                                    onlinebookscount = Convert.ToInt32(rcnt);
                                }

                                if (onlinebookscount == localbookscount)
                                {
                                    Log.Info("updateBookMasterToOnlineLibrary completed successfully");
                                }
                                else
                                {
                                    Log.Error("LibrarySyncingService.updateBookMasterToOnlineLibrary", new Exception("updateBookMasterToOnlineLibrary cannot complete the operation"));
                                }
                            }
                            else
                            {
                                Log.Error("LibrarySyncingService.updateBookMasterToOnlineLibrary", new Exception("updateBookMasterToOnlineLibrary cannot complete the operation"));
                            }


                        }

                    }
                    else
                    {
                        Log.Error("LibrarySyncingService.updateBookMasterToOnlineLibrary", new Exception("updateBookMasterToOnlineLibrary cannot complete the operation"));
                    }

                }


               
            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.updateBookMasterToOnlineLibrary", ex);
            }
            finally
            {
                if (con != null) { con.Close(); }
                    bookmaster.Dispose();
            }
        }


        public void updatePeriodicals()
        {
            Log.Info("updatePeriodicals started");
            SqlConnection con = null;
            DataTable periodicaltable = new DataTable();

            
            try
            {
                string query = "";
                SqlCommand cmd = null;
                SqlDataAdapter adap = null;

                //Local Library SqlConnection
                using (con = Connection.GetLibSqlConnection())
                {
                    //Get ALL Periodicals from local
                    con.Open();
                    query = "select id,title,frequency,subscription_no,fromdate_subcription,todate_subcription,contactno,emailid,subcription_status,type_subscription,amount,location,copies,createddatetime,createdby " +
                            "From Periodicals where subcription_status = 'Active'; ";
                    cmd = new SqlCommand(query, con);
                    adap = new SqlDataAdapter();
                    adap.SelectCommand = cmd;
                    adap.Fill(periodicaltable);
                    con.Close();

                   
                }

                using (con = Connection.GetOnlineLibSqlConnection())
                {
                    //delete periodicals from online database
                    con.Open();
                    query = "Delete from Periodicals;";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    Boolean isexecuted = false;

                    //push the Local Periodicals to online Periodicals
                    SQL sql2 = new SQL("Data Source=" + Connection.onlinelib_sqlserver + ";Initial Catalog=" + Connection.onlinelib_sqldb + ";User ID=" + Connection.onlinelib_sqluser + ";Password=" + Connection.onlinelib_sqlpassword + "");
                    isexecuted = sql2.Backup(periodicaltable, "Periodicals");

                }


                Log.Info("updatePeriodicals completed");
            }
            catch (Exception ex)
            {
                Log.Error("LibrarySyncingService.updatePeriodicals", ex);
            }
            finally
            {
                if (con != null) { con.Close(); }
                periodicaltable.Dispose();
            }
        }

    }
}
