﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrarySyncingService
{
    class EnumClass
    {
        public static string available = "available";
        public static string issued = "issued";
        public static string withdrawn = "withdrawn";
        public static string missing = "missing";
        public static string returned = "returned";
        public static string permanent = "permanent_issued";
        public static string reserved = "reserved";
    }
}
